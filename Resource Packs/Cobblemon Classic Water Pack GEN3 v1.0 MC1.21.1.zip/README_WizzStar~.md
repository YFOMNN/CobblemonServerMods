# Cobblemon Classic Water Pack GEN3
With this small resource pack the Pokémon are harder to see in the wild because they wander between the different grasses, like in the world of Pokémon.

## **Info**
The textures are from Pokémon Emerald Version
I edited the water textures. 



## **This pack includes/replaces**
- [Water_Flow](https://minecraft.fandom.com/wiki/Water)
- [Water Still](https://minecraft.fandom.com/wiki/Water)

## **Optional Dependecies**
- [Cobblemon](https://www.curseforge.com/minecraft/mc-mods/cobblemon)
  
## **To-do**
- _Redo water animation._

## **Credits**
_I did not create or do not own any of these textures/graphics!_  
All credit goes to the rightful creators/owners.

_According to Bulbapedia "All of the background music and sound effects used in the games (RGBY), all of which were composed solely by Junichi Masuda. This includes Pokémon cries and Pokédex entries read by "Dexter", Ash's Pokédex."_

[Junichi Masuda](https://bulbapedia.bulbagarden.net/wiki/Junichi_Masuda)
[Game Freak, Inc.](https://bulbapedia.bulbagarden.net/wiki/Game_Freak)   
[The Pokémon Company](https://bulbapedia.bulbagarden.net/wiki/The_Pok%C3%A9mon_Company)
[Nintendo](https://bulbapedia.bulbagarden.net/wiki/Nintendo)

## **Contact**
_**Discord: WizzStar**_
You can contact me for issues, but also requests and/or ideas.