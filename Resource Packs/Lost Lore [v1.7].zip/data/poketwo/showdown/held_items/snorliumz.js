{
  name: "Snorlium Z",
  spritenum: 656,
  onTakeItem: false,
  zMove: "Pulverizing Pancake",
  zMoveFrom: "Giga Impact",
  itemUser: ["Snorlax", "Snorlax-Snowman"],
  num: 804,
  gen: 7,
  isNonstandard: "Past",
}