{
	name: "Eevium Z",
	spritenum: 657,
	onTakeItem: false,
	zMove: "Extreme Evoboost",
	zMoveFrom: "Last Resort",
	itemUser: ["Eevee", "Eevee-Lana"],
	num: 805,
	gen: 7,
	isNonstandard: "Past",
}