{
  name: "Venusaurite",
  spritenum: 586,
  megaStone: "Venusaur-Mega",
  megaEvolves: ["Venusaur", "Venusaur-Clone"],
  itemUser: ["Venusaur"],
  onTakeItem(item, source) {
  	if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
  	return true;
  },
  num: 678,
  gen: 6,
  isNonstandard: "Past",
}