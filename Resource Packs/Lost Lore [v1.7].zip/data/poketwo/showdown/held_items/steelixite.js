{
	name: "Steelixite",
	spritenum: 621,
	megaStone: "Steelix-Mega",
	megaEvolves: ["Steelix", "Steelix-Crystal"],
	itemUser: ["Steelix"],
	onTakeItem(item, source) {
		if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
		return true;
	},
	num: 761,
	gen: 6,
	isNonstandard: "Past",
}