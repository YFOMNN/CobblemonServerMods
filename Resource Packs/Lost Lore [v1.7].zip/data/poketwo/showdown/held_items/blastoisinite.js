{
  name: "Blastoisinite",
  spritenum: 586,
  megaStone: "Blastoise-Mega",
  megaEvolves: ["Blastoise", "Blastoise-Clone"],
  itemUser: ["Blastoise"],
  onTakeItem(item, source) {
  	if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
  	return true;
  },
  num: 678,
  gen: 6,
  isNonstandard: "Past",
}