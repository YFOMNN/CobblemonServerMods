{
  name: "Mimikium Z",
  spritenum: 688,
  onTakeItem: false,
  zMove: "Let's Snuggle Forever",
  zMoveFrom: "Play Rough",
  itemUser: ["Mimikyu", "Mimikyu-Busted", "Mimikyu-Acerola", "Mimikyu-Busted-Acerola", "Mimikyu-Totem", "Mimikyu-Busted-Totem"],
  num: 924,
  isNonstandard: "Past",
  gen: 7,
}