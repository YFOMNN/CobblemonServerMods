{
  name: "Dark Tyranitarium Z",
  spritenum: 999,
  onTakeItem: false,
  zMove: "Kaiju Cataclysm",
  zMoveFrom: "Rock Wrecker",
  itemUser: ["Tyranitar-Black"],
  num: 999,
  gen: 7,
  isNonstandard: "Past",
}